﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Contacts;

namespace LAb13_2
{
    class Program
    {
        static void Main(string[] args)
        {

            SerializeData();
           DeserializeData();

        }
        private static void SerializeData()
        {
            List<Contact> ContactList = new List<Contact>();
            try
            {
                Console.WriteLine("Enter number of contacts");
                int n = int.Parse(Console.ReadLine());

                for (int index = 0; index < n; index++)
                {
                    Contact objContact = new Contact();
                    Console.WriteLine(" contact details");
                    objContact.ContactNo = int.Parse(Console.ReadLine());
                    objContact.ContactName = Console.ReadLine();
                    objContact.CellNo = Console.ReadLine();
                    ContactList.Add(objContact);
                }

                    FileStream fileStream = new FileStream("C:\\Users\\mohdsalk\\Documents\\ser.dat", FileMode.Create);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                binaryFormatter.Serialize(fileStream, ContactList);
                fileStream.Close();
                Console.Write("Suceessful!!!!!!");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void DeserializeData()
        {
            try
            {
                FileStream fileStream = new FileStream("C:\\Users\\mohdsalk\\Documents\\ser.dat", FileMode.Open);
                BinaryFormatter binaryFormatter = new BinaryFormatter();
                List<Contact> obj = (List<Contact>)binaryFormatter.Deserialize(fileStream);
                fileStream.Close();
                foreach (Contact c in obj)
                {
                    Console.WriteLine("Cell No:" + c.CellNo + "Name:" + c.ContactName);
                }

             

            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
    }

